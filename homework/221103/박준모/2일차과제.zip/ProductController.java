package my.control;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import test.model.ProductDAO;
import test.model.ProductDTO;

@Controller
public class ProductController {

	@Autowired
	ProductDAO prdDAO;

	@RequestMapping(value = "/insertProduct", method = RequestMethod.GET)
	public String insertPool(String product, int count, String date, Model model) {

		String result = prdDAO.insertProduct(product, count, date);
		model.addAttribute("result", result);

		return "insertProduct";
	}

	@RequestMapping(value = "/selectProduct", method = RequestMethod.GET)
	public String selectProduct(Model model) {

		ArrayList<ProductDTO> arr = prdDAO.selectProduct();
		model.addAttribute("arr", arr);

		return "selectProduct";
	}

}
