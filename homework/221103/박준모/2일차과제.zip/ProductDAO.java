package test.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ProductDAO {

	@Autowired
	BasicDataSource dataSource;

	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	
	public String insertProduct(String product, int count, String date) {

		try {
			String sql = "insert into product values(?,?,?)";
			conn = dataSource.getConnection();
			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, product);
			pstmt.setInt(2, count);
			pstmt.setString(3, date);

			int nCnt = pstmt.executeUpdate(); // insert, update, delete 의 경우 반영된 갯수 return

			conn.close(); // dbpool에 connection 반납

			return "추가 성공 : " + nCnt;
		} catch (Exception err) {
			return "추가 실패 : " + err.getMessage();
		}
	}
	
	public ArrayList<ProductDTO> selectProduct() {
		ArrayList<ProductDTO> arr = new ArrayList<ProductDTO>();
		try {
			String sql = "select * from product";
			
			conn = dataSource.getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				String product = rs.getString("product");
				int count = rs.getInt("count");
				String date = rs.getString("date");
				arr.add(new ProductDTO(product, count, date));
			}
			rs.close();
			conn.close();

			return arr;
			
		} catch (Exception ex) {
			return null;
		}

	}

}
