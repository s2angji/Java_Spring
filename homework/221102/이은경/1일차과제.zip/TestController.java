package my.control;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class TestController {
	@RequestMapping(value = "/test_01", method = RequestMethod.GET)
	public String test01(int weight, int height, Model model) {
		
		int standard = (int) ((height - 100) * 0.85);
		int bmi = weight/standard*100;
		
		model.addAttribute("weight", weight);
		model.addAttribute("height", height);
		model.addAttribute("standard", standard);
		model.addAttribute("bmi", bmi);
		return "test_01"; 
	}
	
	@RequestMapping(value = "/test_02", method = RequestMethod.GET)
	public String test02(HttpServletRequest request, Model model) {
		String[] topping = request.getParameterValues("topping");
		model.addAttribute("name", request.getParameter("name"));
		model.addAttribute("tel", request.getParameter("tel"));
		model.addAttribute("email", request.getParameter("email"));
		model.addAttribute("size", request.getParameter("size"));
		model.addAttribute("topping", topping);
		model.addAttribute("time", request.getParameter("time"));
		model.addAttribute("text", request.getParameter("text"));
		return "test_02"; 
	}
}
