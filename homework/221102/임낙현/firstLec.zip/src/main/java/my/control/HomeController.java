package my.control;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.core.SpringVersion;

import java.text.DateFormat;
import java.util.Date;
import java.io.PrintWriter;
import java.io.IOException;

import java.util.Locale;
import java.util.ArrayList;
import java.util.Arrays;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.ui.Model;
import org.springframework.beans.factory.annotation.Autowired;
import java.sql.*;


@Controller
public class HomeController {
    // test/home 이라고 들어왔을 때 
	@RequestMapping(value = "/home", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		
		// control
		return "a"; // forward: view a.jsp
	}
	
	@RequestMapping("/formproc")
	public String formproc(HttpServletRequest request, Model model) {
		
		String s = request.getParameter("myname");
		String a = request.getParameter("myage");
		System.out.println("내 이름 : " + s);
		System.out.println("내 나이 : " + a);
		
		model.addAttribute("name", s);
		model.addAttribute("age", a);
		
		return "01.view";
	}
	
	@RequestMapping("/param")
	public String param(String myname, int myage, String mybirth, Model model) {
		
		model.addAttribute("myname", myname);
		model.addAttribute("myage", myage);
		model.addAttribute("mybirth", mybirth);
		
		String[] myarr = {"사과", "딸기", "포도"};
		model.addAttribute("myarr", myarr);
		
		return "02.view";
	}
	
//	@RequestMapping("/02.view.jsp")
//	public String goview02() {
//		return "02.jstl";
//	}
	
	@RequestMapping("/calc")
	public String calc(int num1, int num2, Model model) {
		
		model.addAttribute("result", num1 + num2);
		
		return "10.view";
	}

	@RequestMapping("/obesity")
	public String obesity(double tall, double weight, Model model) {
		
		model.addAttribute("tall", tall);
		model.addAttribute("weight", weight);
		
		double standardWeight = (tall - 100) * 0.85;
		double obesityRate = weight / standardWeight * 100;
		
		String result = (obesityRate <= 90) ? "저체중" : (obesityRate <= 110) ? "정상" : (obesityRate <= 120) ? "과체중" : "비만";
		model.addAttribute("result", result);
		System.out.println("키 : " + tall);
		System.out.println("몸무게 : " + weight);
		System.out.println("비만도 : " + obesityRate);
		return "03.prob";
	}
	
	@RequestMapping("/pizza")
	public String pizza(HttpServletRequest request, Model model) {
		
		model.addAttribute("customerName", request.getParameter("customerName"));
		model.addAttribute("customerTel", request.getParameter("customerTel"));
		model.addAttribute("customerEmail", request.getParameter("customerEmail"));
		model.addAttribute("size", request.getParameter("size"));
		model.addAttribute("topping", request.getParameter("topping"));
//		model.addAttribute("customerName", request.getParameter("customerName"));
//		model.addAttribute("customerName", request.getParameter("customerName"));
//		model.addAttribute("customerName", request.getParameter("customerName"));
		
		String[] topping = request.getParameterValues("topping");
//		System.out.println(request.getParameter("size"));
		System.out.println(Arrays.toString(topping));
//		model.addAttribute("result", result);

		return "";
	}
	
}


