package my.control;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MyController {

	@RequestMapping(value="/b")
	public String bFn(Model model) {
		model.addAttribute("number", 10);
		
		return "b";
	}
	
}
