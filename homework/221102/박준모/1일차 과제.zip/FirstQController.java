package my.control;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class FirstQController {

	@RequestMapping(value = "/firstQ1")
	public String bFn(int height, int weight, Model model) {
		double stdWeight = (height - 100) * 0.85;
		model.addAttribute("height", height);
		model.addAttribute("weight", weight);
		model.addAttribute("obesity", weight / stdWeight * 100);
		return "01.firstQ";
	}

	@RequestMapping(value = "/firstQ2")
	public String firstQ2(String name, String tel, String email, String size, String[] topping, String time,
			String request, Model model) {

		model.addAttribute("name", name);
		model.addAttribute("tel", tel);
		model.addAttribute("email", email);
		model.addAttribute("size", size);
		model.addAttribute("topping", topping);
		model.addAttribute("time", time);
		model.addAttribute("request", request);
		return "02.firstQ";
	}
}
